@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Add New Menu Item</h1>

    <form action="{{ route('admin.menu-items.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
            <label>Price</label>
            <input type="number" name="price" class="form-control" step="0.01" required>
        </div>

        <div class="mb-3">
            <label>Image (optional)</label>
            <input type="file" name="image" class="form-control">
        </div>

        <div class="form-check mb-3">
            <input type="checkbox" name="available" class="form-check-input" id="available" checked>
            <label class="form-check-label" for="available">Available</label>
        </div>

        <button class="btn btn-primary" type="submit">Save</button>
    </form>
</div>
@endsection
