@extends('layouts.app')

@section('content')
<div class="container">
    <h1 class="mb-4">Our Menu</h1>

    <div class="row">
        @foreach ($menuItems as $item)
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    @if ($item->image)
                        <img src="{{ asset('storage/' . $item->image) }}" class="card-img-top" alt="{{ $item->name }}">
                    @endif
                    <div class="card-body">
                        <h5 class="card-title">{{ $item->name }}</h5>
                        <p class="card-text">{{ $item->description }}</p>
                        <p class="fw-bold">Rp {{ number_format($item->price, 0, ',', '.') }}</p>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
